package com.zenklub.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.zenklub.base.baseclass;
import com.zenklub.pages.HomePage;
import com.zenklub.pages.LoginPage;
import com.zenklub.pages.ProfessionalDetailsPage;
import com.zenklub.pages.ProfessionalPage;
import com.zenklub.utils.Utilclass;

public class ProfessionalVerficationTest extends baseclass {

	Utilclass utilclass;
	LoginPage loginPage;
	HomePage homePage;
	ProfessionalPage professionalPage;
	ProfessionalDetailsPage professionalDetailsPage;

	public ProfessionalVerficationTest() {
		super();
	}

	@BeforeMethod
	public void setUp() throws InterruptedException {
		initialization();

		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		professionalPage = new ProfessionalPage();
		professionalDetailsPage = new ProfessionalDetailsPage();
		Thread.sleep(7000);
	}

	@Test
	public void VerifyProfessional() throws InterruptedException {
		// Verifying User Name in user dropdown
		String username = homePage.validateUser();
		Assert.assertEquals(username, "Olá, QA");

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Verifying the Page title
		String title = loginPage.validateLoginPageTitle();
		Assert.assertEquals(title, "Zenklub | Consulte um psicólogo ou terapeuta online");

		// Zenklub logo verification
		boolean validate = loginPage.validateZenklubImage();
		Assert.assertEquals(true, validate);

		// Homepage

		// Verifying Zenklub logo
		homePage.validateZenklublogo();

		// Verifying am on Professional List page
		homePage.listOfProfessional();

		// Professional list page

		// Validating URL
		String professionalURL = professionalPage.validatelistPageURL();
		Assert.assertEquals(professionalURL, "https://zenklub.com.br/busca/");

		// Getting 1st professional Name
		String listName = professionalPage.getFirstProfessionalName();
		System.out.println("listName : " + listName);

		// Getting 1st professional CRP number
		String listCRP = professionalPage.getCRPValue();
		System.out.println("listCRP : " + listCRP);

		// Click on the first professional
		professionalPage.clickProfile();

		// Get the clicked professional name
		String clickedProfilesName = professionalDetailsPage.getClickedProfileName();
		System.out.println("clickedProfilesName : " + clickedProfilesName);

		// Get the clicked professional CRP value
		String clickedProfilesCRPValue = professionalDetailsPage.getClickedProfCRP();
		System.out.println("clickedProfilesCRPValue : " + clickedProfilesCRPValue);

		// Verifying List page professional name with Clicked professional name
		Assert.assertEquals(listName, clickedProfilesName, "Professinal name not matched");

		// Verifying List page professional CRP value with Clicked professional CRP value
		Assert.assertEquals(listCRP, clickedProfilesCRPValue, "Professinal CRP not matched");

	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
