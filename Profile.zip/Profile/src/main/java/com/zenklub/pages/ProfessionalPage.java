package com.zenklub.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zenklub.base.baseclass;

public class ProfessionalPage extends baseclass {

	// Page Factory - OR:
	@FindBy(xpath = "//input[@placeholder='Procure por motivo, nome ou especialidade...']")
	WebElement seaaProfessional;

	@FindBy(xpath = "(//h2)[1]")
	WebElement nameTag;

	@FindBy(xpath = "(//*[contains(text(),' Gostei 💜 quero saber mais! ')])[1]")
	WebElement firstProfessional;

	@FindBy(xpath = "(//h2)[1]")
	WebElement firstProfessionalName;

	@FindBy(xpath = "(//span)[7]")
	WebElement firstProfessionalCRP;

	JavascriptExecutor js;
	String Name = "";
	String CRP = "";
	String Profession = "";

	// Initializing the Page Objects:
	public ProfessionalPage() {
		PageFactory.initElements(driver, this);
		js = (JavascriptExecutor) driver;
	}

	// Actions:

	public boolean validateSearchbar() {
		return seaaProfessional.isDisplayed();
	}

	public String validatelistPageURL() throws InterruptedException {
		Thread.sleep(10000);
		return driver.getCurrentUrl();

	}

	public String validateFirstName() throws InterruptedException {
		Thread.sleep(2000);
		return nameTag.getText();

	}

	public void clickProfile() {
		firstProfessional.click();
	}

	public String getFirstProfessionalName() {
		String nameProfessional = firstProfessionalName.getText();
		return nameProfessional;
	}

	public String getCRPValue() {
		String crpProfessional = firstProfessionalCRP.getText();
		return crpProfessional;
	}

}
