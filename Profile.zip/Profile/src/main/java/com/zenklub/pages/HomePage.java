package com.zenklub.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zenklub.base.baseclass;
import com.zenklub.utils.Utilclass;

public class HomePage extends baseclass {

	// Page Factory - OR:
	@FindBy(xpath = "//span[contains(text(),'Agendar Sessão')]")
	WebElement searchProfessional;

	@FindBy(xpath = "//a[@class='logo']")
	WebElement logoHomepage;

	@FindBy(xpath = "//div[@class='user_info']")
	WebElement userName;

	// Initializing the Page Objects:
	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	// Ations
	
	public String validateUser() {
		return userName.getText();

	}

	public boolean validateZenklublogo() {
		return logoHomepage.isDisplayed();
	}

	public ProfessionalPage listOfProfessional() {
		searchProfessional.click();
		driver.manage().timeouts().pageLoadTimeout(Utilclass.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		return new ProfessionalPage();
	}

}
