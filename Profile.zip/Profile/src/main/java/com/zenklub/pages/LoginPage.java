package com.zenklub.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zenklub.base.baseclass;
import com.zenklub.utils.Utilclass;


public class LoginPage extends baseclass {

	// Page Factory - OR:
	@FindBy(id = "login-form-email")
	WebElement username;

	@FindBy(id = "login-form-password")
	WebElement password;

	@FindBy(xpath = "//button[@class='btn btn-lg btn-primary w-100']")
	WebElement loginBtn;

	@FindBy(xpath = "//a[@class='logo']")
	WebElement ZenklubLogo;

	// Initializing the Page Objects:
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	// Actions:
	public String validateLoginPageTitle() {
		return driver.getTitle();
	}

	public boolean validateZenklubImage() {
		return ZenklubLogo.isDisplayed();
	}

	public HomePage login(String un, String pwd) {
		username.sendKeys(un);
		password.sendKeys(pwd);
		loginBtn.click();
		driver.manage().timeouts().pageLoadTimeout(Utilclass.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		return new HomePage();
	}

}
