package com.zenklub.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zenklub.base.baseclass;

public class ProfessionalDetailsPage extends baseclass {

	JavascriptExecutor js;
	ProfessionalPage professionalPage;

	// Page Factory - OR:
	@FindBy(xpath = "//div[@class='user_info'][1]//h2")
	WebElement openProfessionalName;

	@FindBy(xpath = "(//div[@class='avatar-container vertical']/div[2]/div/span[1])[1]")
	WebElement openProfessionalCRP;
	
	//Actions
	
	public ProfessionalDetailsPage() {
		PageFactory.initElements(driver, this);
		js = (JavascriptExecutor) driver;
		professionalPage = new ProfessionalPage();

	}

	public String getClickedProfileName() {
		String clickedName = openProfessionalName.getText();
		return clickedName;

	}

	public String getClickedProfCRP() {
		String clickedCRP = openProfessionalCRP.getText();
		return clickedCRP;

	}

}
